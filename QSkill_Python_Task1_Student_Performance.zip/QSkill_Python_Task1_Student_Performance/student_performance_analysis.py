import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load CSV file
df = pd.read_csv("student_performance.csv")

# Basic data analysis
print("First five rows:")
print(df.head())

print("\nDataset information:")
print(df.info())

print("\nAverage values:")
print(df[["Study_Hours", "Attendance", "Math_Score", "Science_Score"]].mean())

# Create average score for each student
df["Average_Score"] = df[["Math_Score", "Science_Score"]].mean(axis=1)

# 1. Bar chart
x = np.arange(len(df))
width = 0.36
plt.figure(figsize=(10, 6))
plt.bar(x - width/2, df["Math_Score"], width, label="Math Score")
plt.bar(x + width/2, df["Science_Score"], width, label="Science Score")
plt.xticks(x, df["Name"], rotation=45)
plt.xlabel("Student")
plt.ylabel("Score")
plt.title("Math and Science Scores by Student")
plt.legend()
plt.tight_layout()
plt.savefig("graphs/01_math_science_bar_chart.png", dpi=150)
plt.show()

# 2. Scatter plot
plt.figure(figsize=(8, 6))
plt.scatter(df["Study_Hours"], df["Average_Score"])
plt.xlabel("Study Hours")
plt.ylabel("Average Score")
plt.title("Study Hours vs Average Score")
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("graphs/02_study_hours_scatter_plot.png", dpi=150)
plt.show()

# 3. Correlation heatmap using Matplotlib
numeric_cols = ["Study_Hours", "Attendance", "Math_Score", "Science_Score"]
corr = df[numeric_cols].corr()

plt.figure(figsize=(8, 6))
im = plt.imshow(corr.values, cmap="viridis", vmin=-1, vmax=1)
plt.colorbar(im, label="Correlation")
plt.xticks(range(len(corr.columns)), corr.columns, rotation=45, ha="right")
plt.yticks(range(len(corr.index)), corr.index)
plt.title("Correlation Heatmap")

for i in range(len(corr.index)):
    for j in range(len(corr.columns)):
        plt.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center")

plt.tight_layout()
plt.savefig("graphs/03_correlation_heatmap.png", dpi=150)
plt.show()

print("\nAnalysis completed. Graphs are saved in the graphs folder.")
