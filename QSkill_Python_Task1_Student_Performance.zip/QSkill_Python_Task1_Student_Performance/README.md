# QSkill Internship - Python Development Task 1

## Student Performance Data Analysis

This project is submitted for **QSkill Internship Program - Python Development, Task 1 (Slab 1: Beginner)**.

### Task requirement
Using the Pandas library, load a CSV file and perform basic data analysis such as calculating averages of selected columns. Use Matplotlib to create visualizations including:
- Bar chart
- Scatter plot
- Heatmap

Finally, provide useful observations from the analysis.

## Dataset
The dataset contains student information:
- Name
- Gender
- Study_Hours
- Attendance
- Math_Score
- Science_Score

Number of students: **10**

## Average values

| Metric | Average |
|---|---:|
| Study Hours | 4.00 |
| Attendance | 85.10% |
| Math Score | 76.10 |
| Science Score | 76.90 |

## Visualizations

### 1. Bar Chart
Compares Math and Science scores for each student.

### 2. Scatter Plot
Shows the relationship between study hours and average score.

### 3. Correlation Heatmap
Shows the correlation between study hours, attendance, Math score and Science score.

## Key observations

1. The average study time is **4.00 hours**.
2. The average attendance is **85.10%**.
3. The average Math score is **76.10**.
4. The average Science score is **76.90**.
5. **Priya** has the highest Math score with **95**.
6. **Sneha** has the highest Science score with **93**.
7. **Neha** has the highest attendance with **96%**.
8. Study Hours and Math Score show a strong positive correlation of **0.98** in this small dataset.
9. Attendance and Science Score show a strong positive correlation of **0.99**.

> Correlation indicates association in this dataset; it does not by itself prove causation.

## How to run

```bash
pip install -r requirements.txt
python student_performance_analysis.py
```

## Project structure

```text
QSkill_Python_Task1_Student_Performance/
├── student_performance.csv
├── student_performance_analysis.py
├── analysis_results.txt
├── requirements.txt
├── README.md
└── graphs/
    ├── 01_math_science_bar_chart.png
    ├── 02_study_hours_scatter_plot.png
    └── 03_correlation_heatmap.png
```

## Internship
**Domain:** Python Development  
**Task:** Task 1 - Student Performance Data Analysis  
**Level:** Slab 1 - Beginner
